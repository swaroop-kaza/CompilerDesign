static
const char *XSM_DEFAULT_DISK = "../xfs-interface/disk.xfs";
